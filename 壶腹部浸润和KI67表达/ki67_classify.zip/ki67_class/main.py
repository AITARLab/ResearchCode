# -*- coding=utf-8 -*-
# @TIME 2024/1/29 13:14
# @Author: lyl
# @File: main.py
# @Software:PyCharm
from train import train
data_file = "data/ki67_all.xlsx"
model_list = ["SVC", "RandomForest", "KN", "GaussianNB", "AdaBoost", "GradientBoost", "XGBoost"]

for model in model_list:
    train(model,data_file)