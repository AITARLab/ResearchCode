ki67_all.xlsx 筛选后的表格数据，每行缺失≥5则删除，其余缺失数据以中位数补全
patient前缀为有CT图的病人
without前缀为无CT图的病人
