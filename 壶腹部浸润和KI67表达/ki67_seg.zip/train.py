# -*- coding=utf-8 -*-
# @TIME 2024/1/17 17:29
# @Author: lyl
# @File: train.py.py
# @Software:PyCharm
# from torch.utils.data import DataLoader
import numpy as np

from module.CNN import *
from module.Densenet import *
from module.Resnet import *
from module.Unet import *
from module.fcn_resnet import *
from log.log import logger_config
from test import *
from data_process.split_data import *
from data_process.dataset import *
import torch.optim
import torch.nn as nn
from metric_function.classification_metric import *
from metric_function.seg_metric import *
from metric_function.visualize import *


def classification_train(task, period, fold, model_name, model_type=None, device=None):
    """

    :param task:
    :param period:
    :param fold:
    :param model_name:
    :param model_type:
    :param device:
    :return:
    """
    writeLog = "log/classfication_log.txt"
    logger = logger_config(log_path=writeLog,
                           logging_name=f"{task} {period} {model_name} train")
    mode = "classification"

    if model_name == "CNN":
        model = CNN(n_classes=2)
    elif model_name == "Resnet":
        model = resnet(model_type=model_type)
        model_name = "{}_{}".format(model_name, model_type)
    elif model_name == "Densenet":
        model = densenet()
    else:
        return
    # 设置参数
    learning_rate = 1e-5

    # optimizer = torch.optim.SGD(model.parameters(), lr=learning_rate)
    loss_fn = nn.CrossEntropyLoss()
    epoch = 20
    batchsize = 2
    # 每个元素为[AUC, ACC, lower, upper, F1_score, precision, sensitivity, specificity]
    val_result = []
    test_result = []
    extest_result = []
    model = model.to(device)

    for fn in range(fold):
        train_str = "log/{}_{}_{} fold_train.txt".format(task, period, fn)
        val_str = "log/{}_{}_{} fold_val.txt".format(task, period, fn)
        train_img, train_mask, train_label = get_data(log_file=train_str, mode=mode, data_root="data/internal")
        val_img, val_mask, val_label = get_data(log_file=val_str, mode=mode, data_root="data/internal")
        train_data = image_dataset(data_image=train_img, data_label=train_label, data_mask=train_mask, mode=mode)
        val_data = image_dataset(data_image=val_img, data_label=val_label, data_mask=val_mask, mode=mode)
        train_dataloader = DataLoader(train_data, batch_size=batchsize)
        val_dataloader = DataLoader(val_data, batch_size=batchsize)
        # logger.info("load data success!")
        optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate, weight_decay=1e-5)
        best_train_value = 0
        best_test_value = 0
        best_extest_value = 0
        train_step = 0
        for n in range(epoch):
            logger.info("{}{} fold {} epoch train{}".format("-" * 20, fn, n, "-" * 20))
            model.train()
            for data in train_dataloader:
                imgs, labels = data
                imgs = imgs.to(device)
                predicts = model(imgs)
                # print(predicts)
                optimizer.zero_grad()
                labels = list(map(int, list(labels)))
                loss = loss_fn(predicts.cpu(), torch.tensor(labels, dtype=torch.long))
                loss.backward()
                optimizer.step()

                if train_step % 10 == 0:
                    logger.info("after {} steps training, the loss is {}".format(train_step, loss))
                train_step += 1

            # 验证集
            true_labels = []
            predicted_labels = []
            labels_scores = []
            model.eval()
            with torch.no_grad():
                for data in val_dataloader:
                    imgs, labels = data
                    imgs = imgs.to(device)
                    predicts = model(imgs)
                    # 保存标签与分数
                    np_predicts = predicts.cpu().detach().numpy()
                    labels = list(map(int, list(labels)))
                    true_labels.extend(labels)
                    predicted_labels.extend(np.argmax(np_predicts, axis=1))
                    for i in range(len(np_predicts)):
                        labels_scores.append(np_predicts[i][1])

                # 评价指标计算
                metric = BinaryClassficationMetrics(true_labels, predicted_labels, labels_scores)
                ACC = metric.calculate_accuracy()
                AUC, lower, upper = metric.calculate_AUC_CI()
                F1_score = metric.calculate_f1_score()
                precision = metric.calculate_precision()
                sensitivity = metric.calculate_sensitivity()
                specificity = metric.calculate_specificity()
                # val_result.append([AUC, ACC, lower, upper, F1_score, precision, sensitivity, specificity])
                logger.info(
                    "val: {:.4f}_AUC {:.4f}_ACC [{:.4f}:{:.4f}]_CI {:.4f}_F1_score {:.4f}_precision {:.4f}_sensitivity {:.4f}_specificity".format(
                        AUC, ACC, lower, upper, F1_score, precision, sensitivity, specificity))

            # 保存当前最好的值
            temp_value = 0.8 * AUC + 0.2 * ACC
            if temp_value > best_train_value:
                best_train_value = temp_value
                train_best = [AUC, ACC, lower, upper, F1_score, precision, sensitivity, specificity]

                if os.path.exists("weights") == False:
                    os.mkdir("weights")
                save_path = "weights/{}_{}_{}_{}fold_{}epoch_{:.4f}AUC_{:.4f}ACC.pth".format(task, period, model_name, fn, n, AUC,
                                                                                          ACC)
                torch.save(model, save_path)
                logger.info("weight save path:{}".format(save_path))
                # val 混淆矩阵图与roc
                if os.path.exists("results") == False:
                    os.mkdir("results")
                roc_and_cm_title = "results/{}_{}_{}_{}fold_{}epoch".format(task, period, model_name, fn, n)
                draw_roc(true_labels, labels_scores, roc_and_cm_title + "_val")
                draw_cm(true_labels, predicted_labels, roc_and_cm_title + "_val", labels_name=[0, 1])
                logger.info("roc and cm image save path: {}_val".format(roc_and_cm_title))
                # 内部测试集
                log_intest_data = f"log/{task}_{period}_test.txt"
                test_root = "data/internal"
                test_temp = classification_test(log_file=log_intest_data, model_pth=save_path,
                            pic_title=roc_and_cm_title+"_test", data_root=test_root, writeLog=writeLog, device=device)
                if 0.8 * test_temp[0] + 0.2 * test_temp[1] > best_test_value:
                    test_best = test_temp

                # 外部测试集
                log_extest_data = f"log/{task}_{period}_external test.txt"
                extest_root = "data/external"
                extest_temp = classification_test(log_file=log_extest_data, model_pth=save_path,
                              pic_title=roc_and_cm_title + "_extest", data_root=extest_root, writeLog=writeLog, device=device)
                if 0.8 * extest_temp[0] + 0.2 * extest_temp[1] > best_extest_value:
                    extest_best = extest_temp

        # 每折最佳值
        logger.info("{} {}fold best performance {}".format("-" * 20, fn, "-" * 20))
        val_result.append(train_best)
        test_result.append(test_best)
        extest_result.append(extest_best)
        logger.info('VAL:   AUC:{:.4f}  ACC:{:.4f}  CI:[{:.4f}, {:.4f}] F1_score:{:.4f}  precision:{:.4f}   sensitivity:{:.4f}  specificity:{:.4f}'.format(*train_best))
        logger.info('TEST:   AUC:{:.4f}  ACC:{:.4f}  CI:[{:.4f}, {:.4f}] F1_score:{:.4f}  precision:{:.4f}   sensitivity:{:.4f}  specificity:{:.4f}'.format(*test_best))
        logger.info('EXTEST:   AUC:{:.4f}  ACC:{:.4f}  CI:[{:.4f}, {:.4f}] F1_score:{:.4f}  precision:{:.4f}   sensitivity:{:.4f}  specificity:{:.4f}'.format(*extest_best))

    # AUC, ACC, lower, upper, F1_score, precision, sensitivity, specificity指标均值
    val_mean = np.mean(np.array(val_result), axis=0)
    test_mean = np.mean(np.array(test_result), axis=0)
    extest_mean = np.mean(np.array(extest_result), axis=0)
    logger.info("{} avg performance {}".format("-" * 20, "-" * 20))
    logger.info('VAL:   AUC:{:.4f}  ACC:{:.4f}  CI:[{:.4f}, {:.4f}] F1_score:{:.4f}  precision:{:.4f}   sensitivity:{:.4f}  specificity:{:.4f}'.format(*val_mean))
    logger.info('TEST:   AUC:{:.4f}  ACC:{:.4f}  CI:[{:.4f}, {:.4f}] F1_score:{:.4f}  precision:{:.4f}   sensitivity:{:.4f}  specificity:{:.4f}'.format(*test_mean))
    logger.info('EXTESTL:   AUC:{:.4f}  ACC:{:.4f}  CI:[{:.4f}, {:.4f}] F1_score:{:.4f}  precision:{:.4f}   sensitivity:{:.4f}  specificity:{:.4f}'.format(*extest_mean))


def seg_train(task, period, fold, model_name, model_type=None, device=None):
    writeLog = "log/seg_log/txt"
    logger = logger_config(log_path=writeLog,
                           logging_name=f"{task} {period} {model_name} train")
    mode = "seg"
    # 选取模型
    if model_name == "fcn_resnet":
        model = fcn(num_classes=2, model_type=model_type)
        model_name = "{}_{}".format(model_name, model_type)
    elif model_name == "UNet":
        model = UNet(in_channels=3, num_classes=2)
    else:
        return
    # 设置参数
    batchsize = 4
    learning_rate = 0.0001
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate, weight_decay=1e-5)
    loss_fn = nn.CrossEntropyLoss()
    epoch = 50
    metric = SegmentationMetric(numClass=2)
    train_best = []
    test_best = []
    extest_best = []

    model = model.to(device)
    for fn in range(fold):
        train_str = "log/{}_{}_{} fold_train.txt".format(task, period, fn)
        val_str = "log/{}_{}_{} fold_val.txt".format(task, period, fn)
        train_img, train_mask = get_data(log_file=train_str, mode=mode, data_root="data/internal")
        val_img, val_mask = get_data(log_file=val_str, mode=mode, data_root="data/internal")
        train_data = image_dataset(data_image=train_img, data_mask=train_mask, mode=mode)
        val_data = image_dataset(data_image=val_img, data_mask=val_mask, mode=mode)
        train_dataloader = DataLoader(train_data, batch_size=batchsize)
        val_dataloader = DataLoader(val_data, batch_size=batchsize)
        logger.info("load data success!")

        train_step = 0
        best_trian_iou = 0
        best_test_iou = 0
        best_extest_iou = 0
        model.train()
        for n in range(epoch):
            for data in train_dataloader:
                imgs, masks = data
                masks = masks.to(torch.long)
                imgs, masks = imgs.to(device), masks.to(device)
                predicts = model(imgs)
                # print(torch.argmax(predicts, dim=1).size())
                # predicts = torch.arg(predicts, dim=1)
                # 反向传播

                optimizer.zero_grad()
                loss = loss_fn(predicts, masks)
                loss.backward()
                optimizer.step()

                if train_step % 10 == 0:
                    logger.info("after {} steps training, the loss is {}".format(train_step, loss))
                train_step += 1

            # 验证集
            model.eval()
            metric.reset()
            with torch.no_grad():
                for data in val_dataloader:
                    imgs, masks = data
                    imgs, masks = imgs.to(device), masks.to(device)
                    predicts = model(imgs)
                    # 指标计算
                    predicts = torch.argmax(predicts, dim=1)
                    masks = masks.to(torch.long)
                    metric.addBatch(predicts.cpu(), masks.cpu())

                acc = metric.meanPixelAccuracy()
                iou = metric.meanIntersectionOverUnion()
                dice = metric.Dice_score()
                logger.info("val: ACC {:.4f} IOU {:.4f} DICE {:.4f}".format(acc, iou, dice))

            if iou > best_trian_iou:
                best_trian_iou, best_train_acc, best_train_dice= iou, acc, dice
                # 保存best_iou的模型参数
                save_path = "weights/{}_{}_{}_{}fold_{}epoch_{:.4f}ACC_{:.4f}IOU_{:.4f}DICE.pth".format(task, period, model_name,
                                                                                                     fn, n, acc, iou, dice)
                torch.save(model, save_path)
                logger.info("save_path: {}".format(save_path))

                # 内部测试集
                log_test_data = f"log/{task}_{period}_test.txt"
                test_root = "data/internal"
                ACC, IOU, DICE = seg_test(log_file=log_test_data, model_pth=save_path, writeLog=writeLog,
                                          data_root=test_root, device=device)
                if best_test_iou < IOU:
                    best_test_iou, best_test_acc, best_test_dice = IOU, ACC, DICE

                # 外部部测试集
                log_test_data = f"log/{task}_{period}_external test.txt"
                test_root = "data/internal"
                ACC, IOU, DICE = seg_test(log_file=log_test_data, model_pth=save_path, writeLog=writeLog,
                                          data_root=test_root, device=device)
                if best_extest_iou < IOU:
                    best_extest_iou,best_extest_acc,best_extest_dice = IOU, ACC, DICE

        # 保存每一折的最佳值
        train_best.append([best_train_acc, best_trian_iou, best_train_dice])
        test_best.append([best_test_acc, best_test_iou, best_test_dice])
        extest_best.append([best_extest_acc, best_extest_iou, best_extest_dice])
        logger.info("{} {}fold best performance {}".format("-" * 20, fn, "-" * 20))
        logger.info("VAL:   acc:{:.4f}  iou:{:.4f}  dice:{:.4f}".format(best_train_acc, best_trian_iou, best_train_dice))
        logger.info("TEST:   acc:{:.4f}  iou:{:.4f}  dice:{:.4f}".format(best_test_acc, best_test_iou, best_test_dice))
        logger.info("EX-TEST:   acc:{:.4f}  iou:{}  dice:{:.4f}".format(best_extest_acc, best_extest_iou, best_extest_dice))

    # 最佳指标的均值
    train_best = np.array(train_best)
    test_best = np.array(test_best)
    extest_best = np.array(extest_best)
    logger.info("{} avg performance {}".format("-" * 20, "-" * 20))
    logger.info("VAL:   acc:{:.4f}  iou:{:.4f}  dice:{:.4f}".format(np.mean(train_best[:, 0]), np.mean(train_best[:, 1]), np.mean(train_best[:, 2])))
    logger.info("TEST:   acc:{:.4f}  iou:{:.4f}  dice:{:.4f}".format(np.mean(test_best[:, 0]), np.mean(test_best[:, 1]), np.mean(test_best[:, 2])))
    logger.info("EX-TEST:   acc:{:.4f}  iou:{:.4f}  dice:{:.4f}".format(np.mean(extest_best[:, 0]), np.mean(extest_best[:, 1]), np.mean(extest_best[:, 2])))
