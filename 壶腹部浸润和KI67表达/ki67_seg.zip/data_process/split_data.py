# -*- coding=utf-8 -*-
# @TIME 2024/1/16 17:19
# @Author: lyl
# @File: split_data.py
# @Software:PyCharm
import os
import random
import json


def split_trian_and_test(json_path, percent, task, fold):
    """

    :param json_path: 标签的json文件
    :param percent: 测试集的百分比
    :param task: ki67 or soaked or position
    :param type: cancer1 or cancer2
    :return:返回病人的序号的列表
    """
    with open(json_path, encoding='UTF-8') as f:
        content = json.load(f)
    # 该任务总共的病人数量
    if task == "soaked":
        index = 0
    elif task == "ki67":
        index = 1
    elif task == "position":
        index = 2

    patient0 = []
    patient1 = []
    for c in content:
        # print(type(content[c][index]))
        if content[c][index] == 1:
            patient0.append(c)
        elif content[c][index] == 0:
            patient1.append(c)
    number0 = len(patient0)
    number1 = len(patient1)
    total_number = number1 + number0
    print(f"{'-'*20} {task} {'-'*20}")
    print(f"total number0:{len(patient0)} total number1:{len(patient1)}")

    # 按病人划分训练与测试集
    test_number0 = int(number0 * percent)
    test_number1 = int(number1 * percent)
    test_data0 = random.sample(patient0, test_number0)
    test_data1 = random.sample(patient1, test_number1)
    test_data = test_data0 + test_data1
    print(f"test number0:{test_number0} , test number1:{test_number1}")
    # 每折的训练集与验证集
    rest_patient0 = list(set(patient0)-set(test_data0))
    rest_patient1 = list(set(patient1) - set(test_data1))
    rest = rest_patient0 + rest_patient1
    each_fold0 = int((number0 - test_number0) / fold)
    each_fold1 = int((number1 - test_number1) / fold)
    print(f"each_fold_val0:{each_fold0} , each_fold_val1:{each_fold1}")
    print(f"each_fold_train0:{len(rest_patient0)-each_fold0} , each_fold_train1:{len(rest_patient1)-each_fold1}")
    print("-"*40)

    # 按照病人每折对应的训练与验证
    train_data = []
    val_data = []
    temp0 = rest_patient0
    temp1 = rest_patient1
    for i in range(fold):
        val_temp = []
        sample0 = random.sample(rest_patient0, each_fold0)
        sample1 = random.sample(rest_patient1, each_fold1)
        val_temp.extend(sample0)
        val_temp.extend(sample1)
        val_data.append(val_temp)
        train_data.append(list(set(rest) - set(val_temp)))
        temp1 = [x for x in temp1 if x not in sample1]
        temp0 = [x for x in temp0 if x not in sample0]

    return train_data, val_data, test_data


def save_txt(file, data: list):
    """

    :param file:
    :param data:
    :return:
    """
    with open(file, "w") as f:
        for line in data:
            f.write(line)
    print("{} saved!".format(file))


def record_split(task, period, type, json_path, train_data, val_data, test_data):
    """

    :param task:
    :param period:
    :param type:
    :param json_path:
    :param train_data:
    :param val_data:
    :param test_data:
    :return:
    """
    with open(json_path, encoding='UTF-8') as f:
        content = json.load(f)
    if task == "soaked":
        index = 0
    elif task == "ki67":
        index = 1
    elif task == "position":
        index = 2

    test = []
    train = []
    # 读入每个病人的图片路径
    data_root = f"data/internal/{period}/{type}/img"
    files = os.listdir(data_root)
    for f in files:
        patient = f.split("_")[0]
        str = f + " {}\n".format(content[patient][index])
        # print(str)
        if patient in test_data:
            test.append(str)
        elif patient in (train_data[0]+val_data[0]):
            train.append(str)
    # print(train)

    # 记录测试集
    if os.path.exists("log") == False:
        os.mkdir("log")
    test_log = f"log/{task}_{period}_test.txt"
    # print(test_log)
    save_txt(test_log, test)

    for i in range(len(val_data)):
        train_log = f"log/{task}_{period}_{i} fold_train.txt"
        val_log = f"log/{task}_{period}_{i} fold_val.txt"
        val_temp = []
        train_temp =[]
        for t in train:
            patient = t.split("_")[0].split("/")[-1]
            # print(patient)
            if patient in val_data[i]:
                val_temp.append(t)
            elif patient in train_data[i]:
                train_temp.append(t)

        # print(train_log)
        # print(val_log)
        save_txt(train_log, train_temp)
        save_txt(val_log, val_temp)


def record_external_test(task, period, type, json_path):
    """

    :param task:
    :param period:
    :param type:
    :param json_path:
    :return:
    """
    with open(json_path, encoding='UTF-8') as f:
        content = json.load(f)
    if task == "soaked":
        index = 0
    elif task == "ki67":
        index = 1
    elif task == "position":
        index = 2


    test = []
    data_root = f"data/external/{period}/{type}/img"
    for root, paths, files in os.walk(data_root):
        if paths == [] and type in root:
            for f in files:
                temp = f.split("_")
                patient = temp[0]+"_"+temp[1]
                str = f + " {}\n".format(content[patient][index])
                # print(str)
                test.append(str)
                # print(patient)
    if os.path.exists("log") == False:
        os.mkdir("log")
    test_log = f"log/{task}_{period}_external test.txt"
    save_txt(test_log, test)