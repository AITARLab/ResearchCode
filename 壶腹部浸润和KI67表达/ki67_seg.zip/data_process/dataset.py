# -*- coding=utf-8 -*-
# @TIME 2024/1/16 17:08
# @Author: lyl
# @File: dataset.py
# @Software:PyCharm
import os
import cv2
import matplotlib.pyplot as plt
import torch
import torch.utils.data as td
import numpy as np
from torchvision import transforms
from PIL import Image
import time

def get_data(log_file, data_root, mode):
    img = []
    label = []
    mask = []
    with open(log_file, 'r') as f:
        for line in f.readlines():
            new_line = line.strip("\n").split(" ")
            str_lists = new_line[0].split("_")
            if len(str_lists) == 4:
                pid, period, imgid, type = str_lists
            else:
                name, pid, period, imgid, type = str_lists
            # print( [pid, period, imgid,type ])
            img_path = data_root+"/{}/{}/{}/{}".format(period, type[:-4], "img", new_line[0])
            # print(img_path)
            img.append(img_path)
            mask_path = data_root+"/{}/{}/{}/{}".format(period, type[:-4], "mask", new_line[0])
            mask.append(mask_path)
            label.append(new_line[1])

    if mode == 'seg':
        return img, mask
    elif mode == "classification":
        return img, mask, label


def normalize_img(image):
    """
    normalize image to [0,1]
    :param image: input image, numpy
    :return: normalized image
    """
    _range = image.max() - image.min()
    if _range == 0:
        assert _range != 0, "image is empty!"
    assert _range > 0
    return (image - image.min()) / _range


def loader(img_path, mode, mask_path, root=""):
    if root != "":
        img_path = os.path.join(root, img_path)

    img = cv2.imread(img_path)
    mask = cv2.imread(mask_path)
    result = cv2.bitwise_and(img, mask)
    mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
    mask01 = np.zeros(mask.shape[:2], dtype=np.uint8)
    _, binary_image = cv2.threshold(mask, 50, 255, cv2.THRESH_BINARY)
    cv2.bitwise_or(binary_image, mask, mask01)
    mask = mask01
    trans = transforms.Compose([transforms.ToTensor(), transforms.Resize([512, 512])])
    mask = torch.from_numpy(cv2.resize(mask, (512, 512), interpolation=cv2.INTER_NEAREST) / 255)
    if mode == "seg":
        return trans(img), mask
    elif mode == "classification":
        return trans(result)

class image_dataset(td.Dataset):
    def __init__(self, data_image, data_mask, mode, data_label=None, n_classes=2):
        """

        :param data_image:
        :param data_label_or_mask:
        :param mode:
        :param n_classes:
        """
        self.label = data_label
        self.image = data_image
        self.n_classes = n_classes
        self.mode = mode
        self.mask = data_mask

    def __getitem__(self, index):
        if self.mode == 'seg':
            img, mask = loader(img_path=self.image[index], mask_path=self.mask[index], mode="seg")
            return img, mask
        else:
            img = loader(img_path=self.image[index], mask_path=self.mask[index], mode="classification")
            label = self.label[index]
            return img, label

    def __len__(self):
        return len(self.mask)