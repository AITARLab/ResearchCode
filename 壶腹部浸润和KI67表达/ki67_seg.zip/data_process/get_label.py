# -*- coding=utf-8 -*-
# @TIME 2024/1/17 12:11
# @Author: lyl
# @File: get_label.py
# @Software:PyCharm
import pandas as pd
from openpyxl import load_workbook
import json


def get_internal_label(file_path, json_path):
   """

   :param file_path:
   :param json_path:
   :return:
   """
   workbook = load_workbook(file_path)
   sheet = workbook["数据总表"]
   patients_cells = sheet["B6:B68"]
   soaked_cells = sheet["L6:L68"]
   ki67_cells = sheet["R6:R68"]
   type_cells = sheet["F6:F68"]
   label_dict = {}
   for P, S, K, T in zip(patients_cells, soaked_cells, ki67_cells, type_cells):
      for p, s, k, t in zip(P, S, K, T):
         if s.value == "无":
            new_s = 0
         elif s.value == "有":
            new_s = 1
         else:
            new_s = None

         if t.value == "胰头":
            new_t = 1
         else:
            new_t = 0
         label_dict["patient{}".format(p.value)] = [new_s, k.value, new_t]

   print(label_dict)
   with open(json_path, "w") as f:
      json.dump(label_dict, f, indent=4, ensure_ascii=False)


def get_external_label(file_path, json_path):
   """

   :param file_path:
   :param json_path:
   :return:
   """
   workbook = load_workbook(file_path)
   sheet = workbook["数据总表"]
   patients_cells = sheet["B72:B81"]
   soaked_cells = sheet["L72:L81"]
   ki67_cells = sheet["R72:R81"]
   type_cells = sheet["F72:F81"]
   label_dict = {}
   for P, S, K, T in zip(patients_cells, soaked_cells, ki67_cells, type_cells):
      for p, s, k, t in zip(P, S, K,T):
         if s.value == "无":
            new_s = 0
         elif s.value == "有":
            new_s = 1
         else:
            new_s = None

         if t.value == "胰头":
            new_t = 1
         else:
            new_t = 0
         label_dict["zg_patient{}".format(p.value)] = [new_s, k.value, new_t]

   patients_cells = sheet["B84:B93"]
   soaked_cells = sheet["L84:L93"]
   ki67_cells = sheet["R84:R93"]
   type_cells = sheet["F72:F81"]
   for P, S, K, T in zip(patients_cells, soaked_cells, ki67_cells, type_cells):
      for p, s, k, t in zip(P, S, K, T):
         if s.value == "无":
            new_s = 0
         elif s.value == "有":
            new_s = 1
         else:
            new_s = None

         if t.value == "胰头":
            new_t = 1
         else:
            new_t = 0
         label_dict["yb_patient{}".format(p.value)] = [new_s, k.value, new_t]

   print(label_dict)
   with open(json_path, "w") as f:
      json.dump(label_dict, f, indent=4, ensure_ascii=False)



# data_path = "../胰腺癌数据 1-3.xlsx"
# json_path = "../data/external/external_label.json"
# get_external_label(file_path=data_path, json_path=json_path)
# json_path = "../data/internal/internal_label.json"
# get_internal_label(data_path, json_path)