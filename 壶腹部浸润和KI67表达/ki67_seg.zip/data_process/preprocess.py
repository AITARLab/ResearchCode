import os
import shutil
from PIL import Image
import pandas as pd
import numpy as np
import cv2
import json


def json_to_mask(img_path, save_root, save_name, points):
    """

    :param img_path:
    :param save_root:
    :param save_name:
    :param points:
    :return:
    """
    img = cv2.imdecode(np.fromfile(img_path, dtype=np.uint8), -1)
    rgb_channels = cv2.split(img)[:3]
    img = cv2.merge(rgb_channels)
    mask_size = [img.shape[0], img.shape[1]]

    # 只提取黑白mask
    mask = np.zeros(mask_size, np.uint8)
    points_array = np.array(points, dtype=np.int32)
    mask = cv2.fillPoly(mask, [points_array], 255)
    mask_save = "{}/mask/{}".format(save_root, save_name)
    img_save = "{}/img/{}".format(save_root, save_name)
    cv2.imwrite(mask_save, mask)
    cv2.imwrite(img_save, img)

    # 取彩色mask
    # mask = cv2.imread(save_path)
    # result = cv2.bitwise_and(img, mask)
    # cv2.imwrite(save_path, result)

def preprocess(source_root, target_root, dict=None, type=None):
    """

    :param source_root:
    :param target_root:
    :param dict:
    :param type:
    :return:
    """
    if os.path.exists(target_root) == False:
        os.mkdir(target_root)

    for root, paths, files in os.walk(source_root):
        if paths == []:
            i = 0
            for file in files:
                if file[-4:] == 'json':
                    json_path = os.path.join(root, file)
                    img_path = os.path.join(root, file[:-4]+'jpg')
                    if os.path.exists(img_path) == False:
                        img_path = img_path[:-3]+'png'

                    with open(json_path, encoding='UTF-8') as f:
                        content = json.load(f)

                    shapes = content['shapes']
                    for shape in shapes:
                        points = shape["points"]
                        category = shape['label']
                        if category == 'cancer1' or category == 'cancer2':

                            path_split = img_path.split("\\")
                            if "动脉期" in path_split[-2]:
                                temp = "arterial"
                            elif "静脉期" in path_split[-2]:
                                temp = "venous"

                            if type == None:
                                save_name = "patient{}".format(path_split[-3].split(" ")[0])
                            else:
                                save_name = "{}_patient{}".format(type, dict[path_split[-3]])

                            json_save = "../data/json/" + "{}_{}_img{}.json".format(save_name, temp, i)
                            save_name = "{}_{}_img{}_{}.jpg".format(save_name, temp, i, category)
                            save_root = target_root + "/" + temp + "/" + category
                            json_to_mask(img_path, save_root, save_name, points)
                    print(json_save)
                    shutil.copy(json_path, json_save)
                    i = i + 1

def zg_waibu(root, target, dict):
    """

    :param root:
    :param target:
    :param dict:
    :return:
    """
    lists = os.listdir(root)
    for l in lists:
        i = 0
        for fname in os.listdir(root+"/"+l):
            if fname[-4:] == 'json':
                open_path = os.path.join(root, l+"/"+fname)
                img_path = os.path.join(root, l+"/"+fname[:-4]+'png')

                with open(open_path, encoding='UTF-8') as f:
                    content = json.load(f)

                shapes = content['shapes']
                for shape in shapes:
                    category = shape['label']
                    points = shape['points']
                    # 写入
                    if "动脉" in l:
                        temp = "arterial"
                    elif "静脉" in l:
                        temp = "venous"
                    else:
                        temp = "exclude"
                    save_root = target+"/"+temp+"/"+category
                    save_name = "zg_patient{}_{}_img{}_{}.jpg".format(dict[l[:3]], temp, i, category)
                    json_save = "../data/json/" + "zg_patient{}_{}_img{}.json".format(dict[l[:3]], temp, i)
                    json_to_mask(img_path, save_root, save_name, points)
                # print(json_save)
                shutil.copy(open_path, json_save)
                i = i + 1

def count(data_root,save_path):
    """

    :param data_root:
    :param save_path:
    :return:
    """
    lists = os.listdir(data_root)
    patients = []
    time_venous = []
    time_arterial = []
    count_aterial = []
    count_venous = []
    for l in lists:
        l_split = l.split("_")
        p = l_split[0]
        if len(l_split) == 4:
            p = p + "_" +l_split[1]
        # print(p)
        patients.append(p)
        time_venous.append(p + "_" + "venous")
        time_arterial.append(p + "_"+"aterial")

    patients = list(set(patients))
    for p in patients:
        count_venous.append(time_venous.count(p + "_" + "venous"))
        count_aterial.append(time_arterial.count(p + "_"+"aterial"))

    # print(len(patients))
    # print(len(count_aterial))
    count_data = {'patient': patients, "aterial": count_aterial, "venous":count_venous}
    df = pd.DataFrame(count_data)
    df.to_csv(save_path)



# if __name__ == "__main__":
#     # 自贡医院外部数据
#     zg_dict = {'黄胜国': 1, "雷荣举": 2, "李焕珍": 3, "李秋华": 4, "牟友兵": 5,
#                '王良财': 6, '徐祖全': 7, '杨富花': 8, '杨永聪': 9, '邹年真': 10}
#     root = "../外部验证数据/外部验证数据/自贡四院"
#     target = "../data/external"
#     zg_waibu(root, target, zg_dict)

    # 内部数据
    # source_root = "../数据汇总12-16"
    # target_root = "../data/internal"
    # preprocess(source_root, target_root)

    # 宜宾医院外部数据
    # source_root = "../外部验证数据/外部验证数据/宜宾二院/宜宾二院数据"
    # target_root = "../data/external"
    # yb_dict = {'王中秀': 1, '张元仁': 2, '张均会': 3, '曾世容': 4, '杨占君': 5,
    #            '沈文田': 6, '涂雁兵': 7, '牟成光': 8, '罗珍贵': 9, '龚一群': 10}
    # preprocess(source_root, target_root, yb_dict, 'yb')

    # 统计
    # count(data_root="../data/json", save_path="../count.csv")