# -*- coding=utf-8 -*-
# @TIME 2024/1/17 18:04
# @Author: lyl
# @File: main.py
# @Software:PyCharm
from data_process.split_data import *
from train import *



in_json_path = "data/internal/internal_label.json"
in_data_root = "data/internal"
ex_json_path = "data/external/external_label.json"
ex_data_root = "data/external"
fold = 5
test_percent = 0.2

""" --------------划分数据集并记录，该部分无需再重复运行---------------"""

period = "venous" #"arterial"  # "venous"
# #ki67# #
# task = "ki67"
# type = "cancer2"
# train_data, val_data, test_data = split_trian_and_test(json_path=in_json_path, percent=test_percent, task=task, fold=fold)
# record_split(task, period, type, in_json_path, train_data, val_data, test_data)
# record_external_test(task=task, period=period, type=type, json_path=ex_json_path)

# #soaked# #
# task = "soaked"
# type = "cancer2"
# train_data, val_data, test_data = split_trian_and_test(json_path=in_json_path, percent=test_percent, task=task, fold=fold)
# record_split(task=task, period=period, type=type, json_path=in_json_path, train_data=train_data, val_data=val_data, test_data=test_data)
# record_external_test(task=task, period=period, type=type, json_path=ex_json_path)


# #position# #
task = "position"
type = "cancer1"
train_data, val_data, test_data = split_trian_and_test(json_path=in_json_path, percent=test_percent, task=task, fold=fold)
record_split(task=task, period=period, type=type, json_path=in_json_path, train_data=train_data, val_data=val_data, test_data=test_data)
record_external_test(task=task, period=period, type=type, json_path=ex_json_path)

"""-------------------------------------------------------"""

"""----------------------训练时运行该部分--------------------"""
# #二分类 # #
# device = torch.device("cuda:2" if torch.cuda.is_available() else "cpu")
# tasks = ["ki67", "soaked", "position"]
# periods = ["arterial", "venous"]
# for task in tasks:
#     for period in periods:
#         classification_train(task=task, period=period, fold=fold, model_name="Densenet", device=device)
#         classification_train(task=task, period=period, fold=fold, model_name="CNN", device=device)
#         classification_train(task=task, period=period, fold=fold, model_name="Resnet", model_type=101, device=device)
#         classification_train(task=task, period=period, fold=fold, model_name="Resnet", model_type=18, device=device)

# #分割# #
# task = "position"
# seg_train(task=task, type=type, fold=fold, model_name="UNet", device=device)
# seg_train(task=task, type=type, fold=fold, model_name="fcn_resnet", model_type=50, device=device)
# seg_train(task=task, type=type, fold=fold, model_name="fcn_resnet", model_type=101, device=device)

"""-----------------------------------------------------"""